This compressed folder contains the following folders and subfolders:

- classification
    - aminoacid
    - nucleotide
- regression
    - aminoacid
    - nucleotide

Both subfolders contain train and test folder with fasta files for submission, along with a trained model that can be loaded into the platform.

You can use these files to test how to create a model in the platform.
