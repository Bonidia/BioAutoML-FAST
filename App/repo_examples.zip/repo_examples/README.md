This compressed folder contains examples to test the models in the repository.
It contains the following folders:

- model2: Binary classification of amino acid sequences
- model55: Multiclass classification of nucleotide sequences

Remember that you can check how every model in the repository was constructed by using the provided Job ID for the model.